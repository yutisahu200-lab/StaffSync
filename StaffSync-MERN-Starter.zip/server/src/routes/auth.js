import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, department: u.department, jobTitle: u.jobTitle });

router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 8) {
      return res.status(400).json({ message: 'Name, email and a password of at least 8 characters are required' });
    }
    // Public registration always creates an Employee; elevated roles must be provisioned by an administrator.
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: 'Email already registered' });
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, passwordHash, role: 'Employee' });
    const token = jwt.sign({ sub: user._id }, process.env.JWT_SECRET, { expiresIn: '8h' });
    res.status(201).json({ token, user: publicUser(user) });
  } catch (e) { res.status(500).json({ message: 'Could not register user' }); }
});
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+passwordHash');
    if (!user || !(await bcrypt.compare(password || '', user.passwordHash))) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    const token = jwt.sign({ sub: user._id }, process.env.JWT_SECRET, { expiresIn: '8h' });
    res.json({ token, user: publicUser(user) });
  } catch { res.status(500).json({ message: 'Could not log in' }); }
});
router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));
export default router;